window.onload = function(){
	document.getElementsByName("phone")[0].addEventListener("keypress", function (evt) {
    if (evt.which != 8 && evt.which != 0 && evt.which < 48 || evt.which > 57)
    {
        evt.preventDefault();
    }
	});

	var comm = document.querySelectorAll('#comm');
	var counter = 1;

	var inter;
	inter = setInterval(() => {carusel(counter, 1);}, 5000);

	function carusel(count){
		let next;
		let before;

			if(count - 1 < 0){
				next = 2;
			} else {
				next = count - 1;
			}

			if(count + 1 > 2){
				before = 0;
			} else {
				before = count + 1;
			}		

			comm[next].classList.remove('upper');
			comm[before].classList.remove('bottom');
			comm[count].classList.remove('showing');

			comm[count].classList.add('bottom');
			comm[before].classList.add('upper');
			comm[next].classList.add('showing');

			counter = next;						
	}

	var timer = document.querySelector('#timer');
	var min = 30;
	var sec = 0;

	var interv = setInterval(() => {timers()},1000);
	
	function timers(){
		if((min != 0) || (sec != 0)){
			if(sec == 0){
				min -= 1;
				sec = 59;
			} else {
				sec -= 1;
			}
			timer.innerHTML = min+' мин. '+sec+' сек.';
		} else {
			clearInterval(interv);
		}
	}

}